function greet(name: string) {
    return "Hello, " + name;
}
console.log(greet("World"));
