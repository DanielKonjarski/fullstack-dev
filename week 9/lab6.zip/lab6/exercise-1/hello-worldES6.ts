const greet = (first: string, last: string): string => {
    return `Hello, ${first} ${last}`;
};
console.log(greet("John", "Doe"));
