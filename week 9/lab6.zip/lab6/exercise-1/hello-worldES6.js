var greet = function (first, last) {
    return "Hello, ".concat(first, " ").concat(last);
};
console.log(greet("John", "Doe"));
