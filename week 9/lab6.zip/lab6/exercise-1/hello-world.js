function greet(name) {
    return "Hello, " + name;
}
console.log(greet("World"));
