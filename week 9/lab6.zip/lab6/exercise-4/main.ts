import { Customer } from "./customer";

let customer1 = new Customer("Charlie", "Johnson", 25);
customer1.greeter();
customer1.getAge();
